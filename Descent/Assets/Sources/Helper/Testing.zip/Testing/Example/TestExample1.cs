﻿
using UnityEngine;
using System;

namespace Descent.Test
{
    /// <summary>
    /// Test Example1 Class.
    /// </summary>
    public class TestExample1 : ITest
    {
        /// <summary>
        /// Run Method.
        /// </summary>
        public void Run()
        {
            throw new NotImplementedException();
        }
    }
}
