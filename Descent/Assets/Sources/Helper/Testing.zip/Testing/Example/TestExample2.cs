﻿
using UnityEngine;
using System;

namespace Descent.Test
{
    /// <summary>
    /// Test Example2 Class.
    /// </summary>
    public class TestExample2 : ITest
    {
        /// <summary>
        /// Run Method.
        /// </summary>
        public void Run()
        {
            
        }
    }
}
