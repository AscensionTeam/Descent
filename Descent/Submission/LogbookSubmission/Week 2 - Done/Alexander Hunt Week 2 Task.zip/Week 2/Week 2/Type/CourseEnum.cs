﻿namespace Week_2
{
    /// <summary>
    /// Course Enum.
    /// </summary>
    public enum Course
    {
        ComputerGamingTechnology
    }
}
