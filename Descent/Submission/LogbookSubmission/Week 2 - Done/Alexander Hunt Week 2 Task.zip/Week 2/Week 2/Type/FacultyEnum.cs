﻿namespace Week_2
{
    /// <summary>
    /// Faculty Enum.
    /// </summary>
    public enum Faculty
    {
        ScienceAndTechnology
    }
}
