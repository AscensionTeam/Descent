﻿using System;

namespace Week_2
{
    /// <summary>
    /// Student Class.
    /// </summary>
    class Student
    {
        public string Name { set; get; }

        public string PersonalTutor { get; set;  }

        public int Id { get; }

        public Faculty Faculty { get; set; }

        public Course Course { get; set; }

        public string CourseTutor { get; set; }

        public Student() { }

        public Student(string Name, string PersonalTutor, int Id, Faculty Faculty, Course Course, string CourseTutor)
        {
            this.Name = Name;
            this.PersonalTutor = PersonalTutor;
            this.Id = Id;
            this.Faculty = Faculty;
            this.Course = Course;
            this.CourseTutor = CourseTutor;
        }

        /// <summary>
        /// Print student instance.
        /// </summary>
        /// <param name="Instance">Student instance.</param>
        public static void Print(Student Instance)
        {
            Console.WriteLine("--------------------------");
            Console.WriteLine("Student Name: " + Instance.Name);
            Console.WriteLine("Personal Tutor: " + Instance.PersonalTutor);
            Console.WriteLine("Student Id: " + Instance.Id);
            Console.WriteLine("Student Faculty: " + Instance.Faculty);
            Console.WriteLine("Student Course: " + Instance.Course);
            Console.WriteLine("Course Tutor: " + Instance.CourseTutor);
            Console.WriteLine("--------------------------");
        }
    }
}
