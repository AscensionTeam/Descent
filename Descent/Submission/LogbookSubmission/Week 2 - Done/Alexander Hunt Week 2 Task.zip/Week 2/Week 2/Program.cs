﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create student bob.
            var Bob = StudentFactory.CreateBob();
            Console.WriteLine("Student Bob Created.");

            // Create student alex.
            var Alex = StudentFactory.CreateAlex();
            Console.WriteLine("Student Alex Created. \n");
            
            // Print student information.
            Student.Print(Bob);
            Console.WriteLine();
            Student.Print(Alex);

            // format.
            Console.WriteLine();

            // Delete students.
            Bob = null;
            Console.WriteLine("Student Bob Deleted.");
            
            Alex = null;
            Console.WriteLine("Student Alex Deleted.");

            // Pause console.
            Console.Read();
        }
    }
}
