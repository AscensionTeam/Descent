﻿namespace Week_2
{
    /// <summary>
    /// Student Factory Class.
    /// </summary>
    static class StudentFactory
    {
        public static Student CreateBob()
        {
            // return new bob.
            return new Student("Bob", "Allan Ark", 1271551, Faculty.ScienceAndTechnology, Course.ComputerGamingTechnology, "Mark Mellon");
        }

        public static Student CreateAlex()
        {
            // return new alex.
            return new Student("Alex", "Allan Ark", 1211421, Faculty.ScienceAndTechnology, Course.ComputerGamingTechnology, "Mark Mellon");
        }
    }
}
