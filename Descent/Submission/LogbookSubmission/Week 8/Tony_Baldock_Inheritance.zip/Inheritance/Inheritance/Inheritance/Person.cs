﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    public class Person
    {
        protected string firstName, lastName;

        public Person(string firstName, string lastName)
        {
            this.firstName = firstName;
            this.lastName = lastName;
        }

        public virtual void PrintInfo()
        {
            Console.WriteLine("Firstname: " + firstName);
            Console.WriteLine("Lastname: " + lastName);
        }
    }
}
