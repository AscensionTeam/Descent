﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Person person1 = new Person("Tony", "Baldock");
            person1.PrintInfo();

            Student student1 = new Student("Joe", "Sampson", 1410139, "Forensic Science");
            student1.PrintInfo();
            student1.Learn();

            Teacher teacher1 = new Teacher("Tommy", "Thompson", 1300, "Computer Games Development");
            teacher1.PrintInfo();
            teacher1.StartLesson();

            Person person2 = new Student("Jay", "Chadwick", 1456012, "Unemployed");
            Student student2 = (Student)person2;
            student2.Learn();

            Console.ReadLine();
        }
    }
}
