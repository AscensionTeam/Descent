﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alex_Hunt_Week8
{
    class Program
    {
        static void Main(string[] args)
        {
            Person person1 = new Person("Alex", "Hunt");
            person1.PrintInfo();

            Student student1 = new Student("John", "Smith", 1323812, "Film Studies");
            student1.PrintInfo();
            student1.Learn();

            Teacher teacher1 = new Teacher("Liam", "Neeson", 1162595, "Acting");
            teacher1.PrintInfo();
            teacher1.StartLesson();

            Person person2 = new Student("John", "Diggle", 151558, "Fighter");
            Student student2 = (Student)person2;
            student2.PrintInfo();
            student2.Learn();

            Console.ReadLine();


        }
    }
}
