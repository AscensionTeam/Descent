﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WK8michael
{
    class Program
    {
        static void Main(string[] args)
        {
            Person person1 = new Person("Michael", "Sharpington");
            person1.PrintInfo();

            Student student1 = new Student("Gary", "Bunn", 1363472, "Zoology");
            student1.PrintInfo();
            student1.Learn();

            Teacher teacher1 = new Teacher("Ian", "Brown", 1724896, "Computer Science");
            teacher1.PrintInfo();
            teacher1.StartLesson();

            Person person2 = new Student("John", "Diggle", 1519938, "Fighter");
            Student student2 = (Student)person2;
            student2.PrintInfo();
            student2.Learn();

            Console.ReadLine();


        }
    }
}
